//  https://www.protractortest.org/#/style-guide

var PageLocators = require ('./SecretLocationLandingPage');

describe('Protractor Secret Location smoke test', function() {
	var thePage = new PageLocators();
	beforeAll(function(){
		browser.ignoreSynchronization = true;
		browser.get(thePage.url)
		.then(() => { 
			browser.driver.manage().window().maximize();
		});
	});
	
	it('launch browser', () => {
		browser.getTitle()
		.then(title => {
			console.log('Promised Page Title: ' + title);
			expect(title).toEqual(thePage.expectedTitle);
		})
	}) 
	  
	it('to check the page title', function() {
		browser.driver.getTitle()
		.then(function(pageTitle) {
			console.log('Secret Location Page Title(2): ' + pageTitle);
			expect(pageTitle).toEqual(thePage.expectedTitle);
		});
	});

	it('click on products to see them and verify the opening text', async function () {
		await thePage.productClick();
		await browser.sleep(2000);
		let text = await thePage.mottoLoc.getText();
		console.log(text);
		expect(text).toBe( thePage.expectedMotto);
	});
});
