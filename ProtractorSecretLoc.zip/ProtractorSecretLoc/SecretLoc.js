// https://www.protractortest.org/#/api?view=ProtractorBy.prototype.buttonText

describe('Protractor Testing', function() {
it('to check the page title', function() {
	browser.ignoreSynchronization = true;
	browser.get('https://www.secretlocation.com/');
	browser.driver.getTitle().then(function(pageTitle) {
		expect(pageTitle).toEqual('Secret Location');
		});
	});

	browser.driver.manage().window().maximize();

	it('click on products to see them', async function () {
		await browser.sleep(2000);
	  //await element(by.xpath('//div[@class="navbar-nav d-none d-lg-block"]/a[contains(text(), "Products")]')).click();// works fine  
		await element(by.css('div.navbar-nav:nth-child(3)')).all(by.tagName('a')).get(1).click(); 
	    await browser.sleep(2000);
        let text = await element(by.xpath('//p[contains(text(), "360")]')).getText()
        console.log(text);
        expect(text).toBe("Creators are bringing their stories to life through 360° video or 3D real-time experiences and want a simple way to distribute their work to both at-home and out-of-home markets. Vusr is a suite of products we developed to distribute, manage and monetize their VR content.");
    });
});
