//  https://www.protractortest.org/#/style-guide
describe('Protractor Secret Location smoke test', function() {
	
	beforeAll(function(){
		browser.ignoreSynchronization = true;
		browser.get('https://www.secretlocation.com/');
		browser.driver.manage().window().maximize();
	});
	
	it('to check the page title', function() {
		browser.driver.getTitle().then(function(pageTitle) {
		expect(pageTitle).toEqual('Secret Location');
	});
	});

	it('click on products to see them avd verify the opening text', async function () {
		await element(by.css('div.navbar-nav:nth-child(3)')).all(by.tagName('a')).get(1).click(); 
	    await browser.sleep(2000);
        let text = await element(by.xpath('//p[contains(text(), "360")]')).getText()
        console.log(text);
        expect(text).toBe("Creators are bringing their stories to life through 360° video or 3D real-time experiences and want a simple way to distribute their work to both at-home and out-of-home markets. Vusr is a suite of products we developed to distribute, manage and monetize their VR content.");
    });
});
