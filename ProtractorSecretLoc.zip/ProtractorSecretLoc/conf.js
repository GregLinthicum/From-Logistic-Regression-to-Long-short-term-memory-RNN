exports.config = {
framework: 'jasmine',
capabilities: {
browserName: 'chrome',
},
specs: ['SecretLoc.js']
};