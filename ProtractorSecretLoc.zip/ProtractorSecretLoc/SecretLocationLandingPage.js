
var PageLocators = function(){
	this.url = "https://www.secretlocation.com/"
	this.products = element(by.css('div.navbar-nav:nth-child(3)')).all(by.tagName('a'));
	this.mottoLoc = element(by.xpath('//p[contains(text(), "360")]'));
	this.expectedTitle = 'Secret Location'
	this.expectedMotto = 'Creators are bringing their stories to life through 360° video or 3D real-time experiences and want a simple way to distribute their work to both at-home and out-of-home markets. Vusr is a suite of products we developed to distribute, manage and monetize their VR content.'
	this.productClick = function(){
		this.products.get(1).click(); 
	};
} ;
module.exports = PageLocators;