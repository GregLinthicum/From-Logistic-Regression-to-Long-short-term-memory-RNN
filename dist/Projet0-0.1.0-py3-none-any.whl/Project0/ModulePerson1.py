class Person:
    "This is a Person One class"
    age = 10

    def greet(self):
        print('Hello')
        
    def __init__(self, r=0, i=0):
        self.real = r
        self.imag = i

    def get_data(self):
        print(f'{self.real}+{self.imag}j')
# Output: 10
print(Person.age)

# Output: <function Person.greet>
print(Person.greet)

# Output: "This is a First person class"
print(Person.__doc__)

harry = Person()
harry.greet()

ppp = Person(6,9).get_data()